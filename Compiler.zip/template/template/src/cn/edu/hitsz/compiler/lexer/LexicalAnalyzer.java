package cn.edu.hitsz.compiler.lexer;

import cn.edu.hitsz.compiler.NotImplementedException;
import cn.edu.hitsz.compiler.symtab.SymbolTable;
import cn.edu.hitsz.compiler.utils.FilePathConfig;
import cn.edu.hitsz.compiler.utils.FileUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.StreamSupport;

/**
 * TODO: 实验一: 实现词法分析
 * <br>
 * 你可能需要参考的框架代码如下:
 *
 * @see Token 词法单元的实现
 * @see TokenKind 词法单元类型的实现
 */
public class LexicalAnalyzer {
    private final SymbolTable symbolTable;   //符号表

    private List<Token> Tokens = new ArrayList<>();   //token序列

    private String input_code ;   //存放文件内容

    public LexicalAnalyzer(SymbolTable symbolTable) {
        this.symbolTable = symbolTable;
    }


    /**
     * 从给予的路径中读取并加载文件内容
     *
     * @param path 路径
     */
    public void loadFile(String path) {
        // TODO: 词法分析前的缓冲区实现
        // 可自由实现各类缓冲区
        // 或直接采用完整读入方法
        this.input_code = FileUtils.readFile(path);
    }

    /**
     * 执行词法分析, 准备好用于返回的 token 列表 <br>
     * 需要维护实验一所需的符号表条目, 而得在语法分析中才能确定的符号表条目的成员可以先设置为 null
     */
    public void run() {
        // TODO: 自动机实现的词法分析过程
        int len = this.input_code.length();  //获取文本长度
        int i = 0;
        while ( true ){       //设置死循环，循环获取源程序内容
            if( len == i){   //读完文本，跳出循环
                break;
            }
            char ch = this.input_code.charAt(i);
            while( ch == ' ' || ch == '\n' || ch == '\t' ){  //跳过空格、换行符、制表符
                if( i < len - 1 ){
                    ch = this.input_code.charAt( ++i );
                }else{
                    break;
                }
            }
            if(Character.isDigit(ch)){   //处理常数
                String temp = "";
                temp = temp + ch ;
                if( i == len -1 ) {
                    break;
                }
                ch = this.input_code.charAt( ++i );
                while(Character.isDigit(ch)){
                    temp += ch ;
                    ch = this.input_code.charAt( ++i );
                }
                i -- ; //回退一个
                Token t = Token.normal("IntConst",temp);
                this.Tokens.add(t);
            }
            else if(Character.isAlphabetic(ch)){   //处理字符串
                String temp = "";
                temp = temp + ch ;
                Token t;
                if( i == len -1 ) {
                    break;
                }
                ch = this.input_code.charAt( ++i );
                while(Character.isAlphabetic(ch)||Character.isDigit(ch)){
                    temp += ch ;
                    ch = this.input_code.charAt( ++i );
                }
                i -- ; //回退一个
                if("return".equals(temp)){
                    t = Token.simple("return");
                    this.Tokens.add(t);
                }else if("int".equals(temp)){
                    t = Token.simple("int");
                    this.Tokens.add(t);
                }
                else{
                    t = Token.normal("id",temp);
                    this.Tokens.add(t);
                    if(!symbolTable.has(temp)){
                        symbolTable.add(temp);
                    }
                }
            }
            else{
                Token t;
                switch(ch){
                    case '=':
                        ch = this.input_code.charAt( ++i );
                        if(ch == '='){
                            t = Token.simple("==");
                            this.Tokens.add(t);
                        }else {
                            i--;
                            t = Token.simple("=");
                            this.Tokens.add(t);
                        }
                        break;
                    case ',':
                        t = Token.simple(",");
                        this.Tokens.add(t);
                        break;
                    case ';':
                        t = Token.simple("Semicolon");
                        this.Tokens.add(t);
                        break;
                    case '+':
                        ch = this.input_code.charAt( ++i );
                        if(ch == '+'){
                            t = Token.simple("++");
                            this.Tokens.add(t);
                        }else {
                            i--;
                            t = Token.simple("+");
                            this.Tokens.add(t);
                        }
                        break;
                    case '-':
                        ch = this.input_code.charAt( ++i );
                        if(ch == '-'){
                            t = Token.simple("--");
                            this.Tokens.add(t);
                        }else {
                            i--;
                            t = Token.simple("-");
                            this.Tokens.add(t);
                        }
                        break;
                    case '*':
                        ch = this.input_code.charAt(++i);
                        if(ch == '*') {
                            t = Token.simple("**");
                            this.Tokens.add(t);
                        }else {
                            i--;
                            t = Token.simple("*");
                            this.Tokens.add(t);
                        }
                        break;
                    case '/':
                        t = Token.simple("/");
                        this.Tokens.add(t);
                        break;
                    case '(':
                        t = Token.simple("(");
                        this.Tokens.add(t);
                        break;
                    case ')':
                        t = Token.simple(")");
                        this.Tokens.add(t);
                        break;
                    default:
                        break;
                }
            }

            i++;
        }
        this.Tokens.add(Token.eof());
    }

    /**
     * 获得词法分析的结果, 保证在调用了 run 方法之后调用
     *
     * @return Token 列表
     */
    public Iterable<Token> getTokens() {
        // TODO: 从词法分析过程中获取 Token 列表
        // 词法分析过程可以使用 Stream 或 Iterator 实现按需分析
        // 亦可以直接分析完整个文件
        // 总之实现过程能转化为一列表即可
        return this.Tokens;

    }

    public void dumpTokens(String path) {
        FileUtils.writeLines(
            path,
            StreamSupport.stream(getTokens().spliterator(), false).map(Token::toString).toList()
        );
    }

}
