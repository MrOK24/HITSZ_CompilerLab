package cn.edu.hitsz.compiler.parser;

import cn.edu.hitsz.compiler.ir.IRValue;
import cn.edu.hitsz.compiler.ir.IRVariable;
import cn.edu.hitsz.compiler.ir.Instruction;
import cn.edu.hitsz.compiler.lexer.Token;
import cn.edu.hitsz.compiler.parser.table.NonTerminal;
import cn.edu.hitsz.compiler.symtab.SourceCodeType;

class Symbol{
    Token token;
    NonTerminal nonTerminal;  //非终结符
    SourceCodeType type;
    IRValue vary;

    private Symbol(Token token, NonTerminal nonTerminal){
        this.token = token;
        this.nonTerminal = nonTerminal;
    }

    private Symbol(Token token, NonTerminal nonTerminal,SourceCodeType type){
        this.token = token;
        this.nonTerminal = nonTerminal;
        this.type = type;
    }

    public Symbol(Token token){
        this.token = token;
        this.nonTerminal = null;
    }

    public Symbol(NonTerminal nonTerminal){
        this.token = null;
        this.nonTerminal = nonTerminal;
    }

    public Symbol(SourceCodeType TYPE){
        this.token = null;
        this.nonTerminal =null;
        this.type = TYPE;
    }

    public Symbol(IRValue vary){
        this.token = null;
        this.nonTerminal = null;
        this.type = null;
        this.vary = vary;
    }

    public Symbol(NonTerminal t,IRValue vary){
        this.token = null;
        this.nonTerminal = t;
        this.type = null;
        this.vary = vary;
    }

    public Token getToken() {
        return token;
    }

    public NonTerminal getNonTerminal() {
        return nonTerminal;
    }

    public boolean isToken(){
        return this.token != null;
    }

    public boolean isNonterminal(){
        return this.nonTerminal != null;
    }
}

