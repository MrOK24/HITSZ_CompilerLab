package cn.edu.hitsz.compiler.asm;

import cn.edu.hitsz.compiler.NotImplementedException;
import cn.edu.hitsz.compiler.ir.*;
import cn.edu.hitsz.compiler.utils.FileUtils;

import java.util.*;


/**
 * TODO: 实验四: 实现汇编生成
 * <br>
 * 在编译器的整体框架中, 代码生成可以称作后端, 而前面的所有工作都可称为前端.
 * <br>
 * 在前端完成的所有工作中, 都是与目标平台无关的, 而后端的工作为将前端生成的目标平台无关信息
 * 根据目标平台生成汇编代码. 前后端的分离有利于实现编译器面向不同平台生成汇编代码. 由于前后
 * 端分离的原因, 有可能前端生成的中间代码并不符合目标平台的汇编代码特点. 具体到本项目你可以
 * 尝试加入一个方法将中间代码调整为更接近 risc-v 汇编的形式, 这样会有利于汇编代码的生成.
 * <br>
 * 为保证实现上的自由, 框架中并未对后端提供基建, 在具体实现时可自行设计相关数据结构.
 *
 * @see AssemblyGenerator#run() 代码生成与寄存器分配
 */
public class AssemblyGenerator {

    // 预处理后的指令
    List<Instruction> processedInstruction = new ArrayList<>();
    // 双射函数
    BMap<String,IRValue> bMap = new BMap<>();
    // 寄存器分配
    List<String> registerAlloccationList = new ArrayList<>(){{
        add("t0");
        add("t1");
        add("t2");
        add("t3");
        add("t4");
        add("t5");
        add("t6");
    }};
    // 目标指令集合
    List<String> targetInstuction = new ArrayList<>(){{
        add(".text");
    }};
    // 预处理后指令所需中间变量计数
    Map<IRValue,Integer> counterMap = new HashMap<>();
    /**
     * 加载前端提供的中间代码
     * <br>
     * 视具体实现而定, 在加载中或加载后会生成一些在代码生成中会用到的信息. 如变量的引用
     * 信息. 这些信息可以通过简单的映射维护, 或者自行增加记录信息的数据结构.
     *
     * @param originInstructions 前端提供的中间代码
     */
    public void loadIR(List<Instruction> originInstructions) {
        // TODO: 读入前端提供的中间代码并生成所需要的信息
        // 指令预处理
        for(Instruction instruction:originInstructions){
            InstructionKind kind = instruction.getKind();
            switch (kind){
                case ADD,MUL,SUB -> {
                    IRValue LHS = instruction.getLHS();
                    IRValue RHS = instruction.getRHS();
                    boolean LHSisImmediate = LHS.isImmediate();
                    boolean RHSisImmediate = RHS.isImmediate();
                    if(LHSisImmediate && RHSisImmediate){   //两个操作数都是立即数 转化为MOV指令
                        IRImmediate LHSimmediate = (IRImmediate) LHS;
                        IRImmediate RHSimmediate = (IRImmediate) RHS;
                        switch (kind){
                            case ADD -> {
                                int temp = LHSimmediate.getValue() + RHSimmediate.getValue();
                                IRImmediate tempImmediate = IRImmediate.of(temp);
                                IRVariable tempIRvariable = IRVariable.temp();
                                Instruction tempInstruction = Instruction.createMov(tempIRvariable,tempImmediate);
                                this.processedInstruction.add(tempInstruction);
                                break;
                            }
                            case SUB -> {
                                int temp = LHSimmediate.getValue() - RHSimmediate.getValue();
                                IRImmediate tempImmediate = IRImmediate.of(temp);
                                IRVariable tempIRvariable = IRVariable.temp();
                                Instruction tempInstruction = Instruction.createMov(tempIRvariable,tempImmediate);
                                this.processedInstruction.add(tempInstruction);
                                break;
                            }
                            case MUL -> {
                                int temp = LHSimmediate.getValue() * RHSimmediate.getValue();
                                IRImmediate tempImmediate = IRImmediate.of(temp);
                                IRVariable tempIRvariable = IRVariable.temp();
                                Instruction tempInstruction = Instruction.createMov(tempIRvariable,tempImmediate);
                                this.processedInstruction.add(tempInstruction);
                                break;
                            }
                            default -> {
                                break;
                            }
                        }
                    }
                    else if(LHSisImmediate && !RHSisImmediate){  //左操作数是立即数
                        switch (kind){
                            case ADD -> {
                                IRVariable tempResult = instruction.getResult();
                                Instruction tempInstruction = Instruction.createAdd(tempResult,RHS,LHS);
                                this.processedInstruction.add(tempInstruction);
                                break;
                            }
                            case MUL -> {
                                IRVariable tempResult = instruction.getResult();
                                Instruction tempInstruction = Instruction.createMul(tempResult,RHS,LHS);
                                this.processedInstruction.add(tempInstruction);
                                break;
                            }
                            case SUB -> {
                                IRVariable tempVariable = IRVariable.temp();
                                Instruction tempMovInstruction = Instruction.createMov(tempVariable,LHS);
                                this.processedInstruction.add(tempMovInstruction);
                                IRVariable tempResult = instruction.getResult();
                                Instruction tempInstruction = Instruction.createSub(tempResult,tempVariable,RHS);
                                this.processedInstruction.add(tempInstruction);
                                break;
                            }
                            default -> {
                                break;
                            }
                        }
                    }
                    else {  //右立即数 or 左右都不是立即数
                        this.processedInstruction.add(instruction);
                        break;
                    }
                    break;
                }
                case MOV -> {
                    this.processedInstruction.add(instruction);
                    break;
                }
                case RET -> { //当遇到 Ret 指令后直接舍弃后续指令
                    this.processedInstruction.add(instruction);
                    // System.out.println(this.processedInstruction);
                    return ;
                }
                default -> {
                    break;
                }
            }
        }
    }


    /**
     * 执行代码生成.
     * <br>
     * 根据理论课的做法, 在代码生成时同时完成寄存器分配的工作. 若你觉得这样的做法不好,
     * 也可以将寄存器分配和代码生成分开进行.
     * <br>
     * 提示: 寄存器分配中需要的信息较多, 关于全局的与代码生成过程无关的信息建议在代码生
     * 成前完成建立, 与代码生成的过程相关的信息可自行设计数据结构进行记录并动态维护.
     */
    public void run() {
        // TODO: 执行寄存器分配与代码生成

        // 中间变量计数
        for(Instruction instruction:processedInstruction){
            switch (instruction.getKind()){
                case ADD,SUB,MUL -> {
                    IRValue tempLHS = instruction.getLHS();
                    IRValue tempRHS = instruction.getRHS();
                    IRValue tempResult = instruction.getResult();
                    if(tempLHS.isIRVariable()){
                        tempLHS = (IRVariable) tempLHS;
                        if(!this.counterMap.containsKey(tempLHS)){
                            this.counterMap.put(tempLHS,1);
                        }else{
                            int tempValue = this.counterMap.get(tempLHS);
                            this.counterMap.remove(tempLHS);
                            this.counterMap.put(tempLHS,tempValue+1);
                        }
                    }
                    if(tempRHS.isIRVariable()){
                        tempRHS = (IRVariable) tempRHS;
                        if(!this.counterMap.containsKey(tempRHS)){
                            this.counterMap.put(tempRHS,1);
                        }else{
                            int tempValue = this.counterMap.get(tempRHS);
                            this.counterMap.remove(tempRHS);
                            this.counterMap.put(tempRHS,tempValue+1);
                        }
                    }
                    if(tempResult.isIRVariable()){
                        tempResult = (IRVariable) tempResult;
                        if(!this.counterMap.containsKey(tempResult)){
                            this.counterMap.put(tempResult,1);
                        }else{
                            int tempValue = this.counterMap.get(tempResult);
                            this.counterMap.remove(tempResult);
                            this.counterMap.put(tempResult,tempValue+1);
                        }
                    }
                    break;
                }
                case MOV -> {
                    IRValue tempResult = instruction.getResult();
                    IRValue tempFrom = instruction.getFrom();
                    if(tempResult.isIRVariable()){
                        tempResult = (IRVariable) tempResult;
                        if(!this.counterMap.containsKey(tempResult)){
                            this.counterMap.put(tempResult,1);
                        }else{
                            int tempValue = this.counterMap.get(tempResult);
                            this.counterMap.remove(tempResult);
                            this.counterMap.put(tempResult,tempValue+1);
                        }
                    }
                    if(tempFrom.isIRVariable()){
                        tempFrom = (IRVariable) tempFrom;
                        if(!this.counterMap.containsKey(tempFrom)){
                            this.counterMap.put(tempFrom,1);
                        }else{
                            int tempValue = this.counterMap.get(tempFrom);
                            this.counterMap.remove(tempFrom);
                            this.counterMap.put(tempFrom,tempValue+1);
                        }
                    }
                    break;
                }
                case RET -> {
                    IRValue tempReturnValue = instruction.getReturnValue();
                    if(tempReturnValue.isIRVariable()){
                        tempReturnValue = (IRVariable) tempReturnValue;
                        if(!this.counterMap.containsKey(tempReturnValue)){
                            this.counterMap.put(tempReturnValue,1);
                        }else{
                            int tempValue = this.counterMap.get(tempReturnValue);
                            this.counterMap.remove(tempReturnValue);
                            this.counterMap.put(tempReturnValue,tempValue+1);
                        }
                    }
                    break;
                }
                default -> {
                    break;
                }
            }
        }
        // System.out.println(this.counterMap);

        // 生成指令
        for(Instruction instruction:this.processedInstruction){
            InstructionKind kind = instruction.getKind();
            switch (kind){
                case ADD,SUB,MUL -> {
                    IRVariable tempResult = instruction.getResult();
                    IRValue tempLHS = instruction.getLHS();
                    IRValue tempRHS = instruction.getRHS();
                    String lhs = "" ;
                    String rhs = "" ;
                    String result = "";
                    String op = "";
                    if(tempRHS.isImmediate()){
                        rhs = rhs + (((IRImmediate) tempRHS).getValue());
                        lhs = allocateRegister(tempLHS);
                        result = allocateRegister(tempResult);
                        switch (kind){
                            case ADD -> {
                                op = "addi";
                                break;
                            }
                            case MUL-> {
                                op = "muli";
                                break;
                            }
                            default -> {
                                break;
                            }
                        }
                    }
                    else{
                        rhs = allocateRegister(tempRHS);
                        lhs = allocateRegister(tempLHS);
                        result = allocateRegister(tempResult);
                        switch (kind){
                            case ADD -> {
                                op = "add";
                                break;
                            }
                            case SUB -> {
                                op = "sub";
                                break;
                            }
                            case MUL -> {
                                op = "mul";
                                break;
                            }
                            default ->{
                                break;
                            }
                        }
                    }
                    String riscvInstruction = "    " + op + " " + result + " " + lhs + " " + rhs;
                    this.targetInstuction.add(riscvInstruction);
                }
                case MOV -> {
                    IRVariable tempResult = instruction.getResult();
                    IRValue tempFrom = instruction.getFrom();
                    String from = "";
                    String result = "";
                    String op = " ";
                    if(tempFrom.isImmediate()){
                        from = from + ((IRImmediate) tempFrom).getValue();
                        result = this.allocateRegister(tempResult);
                        op = "li";
                    }
                    else{
                        from = this.allocateRegister(tempFrom);
                        result = this.allocateRegister(tempResult);
                        op = "mv";
                    }
                    String riscvInstruction ="    " + op + " "  + result + " " + from ;
                    this.targetInstuction.add(riscvInstruction);
                }
                case RET -> {
                    IRValue tempReturnValue = instruction.getReturnValue();
                    String returnValue = this.allocateRegister(tempReturnValue);
                    String riscvInstruction = "    "+"mv"+" "+"a0"+" "+returnValue;
                    this.targetInstuction.add(riscvInstruction);
                }
                default -> {
                    break;
                }
            }
        }
        // System.out.println(this.targetInstuction);
        // System.out.println(this.counterMap);
    }

    public String reallocateRegister(){
        String register = "";
        IRValue tempValue = null;
        for(IRValue value:this.counterMap.keySet()){
            if(this.counterMap.get(value)==0) {
                tempValue = value;
                if(this.bMap.getByValue(tempValue) != null ){
                    register = this.bMap.getByValue(tempValue);
                    break;
                }
            }
        }
        return register;
    }

    public String allocateRegister(IRValue value){
        String register = "";
        if(this.bMap.containsValue(value)){  //
            register = this.bMap.getByValue(value);
            int tempNum = this.counterMap.get(value);
            this.counterMap.remove(value);
            this.counterMap.put(value,tempNum-1);   //使用过一次后减一
        }else{
            if(this.registerAlloccationList.isEmpty()){
                register = reallocateRegister();
                this.bMap.replace(register,value);
                int tempNum = this.counterMap.get(value);  //使用过一次后减一
                this.counterMap.remove(value);
                this.counterMap.put(value,tempNum-1);
            }
            else {
                register = this.registerAlloccationList.get(0);
                this.registerAlloccationList.remove(0);
                this.bMap.replace(register,value);
                int tempNum = this.counterMap.get(value);  //使用过一次后减一
                this.counterMap.remove(value);
                this.counterMap.put(value,tempNum-1);
            }
        }
        return register;
    }


    /**
     * 输出汇编代码到文件
     *
     * @param path 输出文件路径
     */
    public void dump(String path) {
        // TODO: 输出汇编代码到文件
        // throw new NotImplementedException();
        FileUtils.writeLines(path, this.targetInstuction.stream().toList());
    }
}

