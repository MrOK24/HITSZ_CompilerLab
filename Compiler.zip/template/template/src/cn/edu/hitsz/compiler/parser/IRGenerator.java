package cn.edu.hitsz.compiler.parser;

import cn.edu.hitsz.compiler.NotImplementedException;
import cn.edu.hitsz.compiler.ir.IRImmediate;
import cn.edu.hitsz.compiler.ir.IRValue;
import cn.edu.hitsz.compiler.ir.IRVariable;
import cn.edu.hitsz.compiler.ir.Instruction;
import cn.edu.hitsz.compiler.lexer.Token;
import cn.edu.hitsz.compiler.parser.table.Production;
import cn.edu.hitsz.compiler.parser.table.Status;
import cn.edu.hitsz.compiler.parser.table.Term;
import cn.edu.hitsz.compiler.symtab.SymbolTable;
import cn.edu.hitsz.compiler.utils.FileUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

// TODO: 实验三: 实现 IR 生成

/**
 *
 */
public class IRGenerator implements ActionObserver {

    private List<Instruction> IR_list  = new ArrayList<>();
    private Stack<Symbol> symbolStack = new Stack<>();

    @Override
    public void whenShift(Status currentStatus, Token currentToken) {
        // TODO
        // 入栈
        this.symbolStack.push(new Symbol(this.token_analysis(currentToken)));

    }

    public IRValue token_analysis(Token token){
        if(token.getKind().getCode()==52){
            return IRImmediate.of(Integer.parseInt(token.getText()));
        }
        return IRVariable.named(token.getText());
    }

    @Override
    public void whenReduce(Status currentStatus, Production production) {
        // TODO
        switch (production.index()){
            case 1->{
                Symbol temp = symbolStack.peek();  //获取栈顶元素
                symbolStack.pop();
                symbolStack.push(new Symbol(production.head(),temp.vary));
                break;
            }
            case 2,3,4,5->{
                for(Term body:production.body()){
                    symbolStack.pop();
                }
                symbolStack.push(new Symbol(production.head(),IRVariable.named("$")));
                break;
            }
            case 6->{     //E-> id=E
                Symbol from = this.symbolStack.peek();
                this.symbolStack.pop();   // E
                this.symbolStack.pop();   // =
                Symbol temp = this.symbolStack.peek();
                this.symbolStack.pop();   //id
                IRVariable result = (IRVariable)temp.vary;
                Instruction instruction = Instruction.createMov(result,from.vary);  //MOV中间指令生成
                symbolStack.push(new Symbol(production.head(),IRVariable.named("$")));
                IR_list.add(instruction);   //加入中间指令集合
                break;
            }
            case 7->{    //S -> return E
                Symbol temp = symbolStack.peek();
                symbolStack.pop();  //E
                symbolStack.pop();  //return
                Instruction instruction = Instruction.createRet(temp.vary); //产生RET中间指令
                IR_list.add(instruction);    //加入中间指令集合
                symbolStack.push(new Symbol(production.head(),IRVariable.named("$")));
                break;
            }
            case 8->{   //E -> E + A;
                Symbol rhs = symbolStack.peek();
                symbolStack.pop();
                symbolStack.pop();
                Symbol lhs = symbolStack.peek();
                symbolStack.pop();
                IRVariable temp = IRVariable.temp();
                Instruction instruction = Instruction.createAdd(temp,lhs.vary,rhs.vary);  //产生ADD中间指令
                IR_list.add(instruction);   //加入指令集合
                symbolStack.push(new Symbol(production.head(),temp));
                break;
            }
            case 9->{  //E -> E - A;
                Symbol rhs = symbolStack.peek();
                symbolStack.pop();
                symbolStack.pop();
                Symbol lhs = symbolStack.peek();
                symbolStack.pop();
                IRVariable temp = IRVariable.temp();
                Instruction instruction = Instruction.createSub(temp,lhs.vary,rhs.vary);  //产生SUB中间代码
                IR_list.add(instruction);  //加入指令集合
                symbolStack.push(new Symbol(production.head(),temp));
                break;
            }
            case 10,12,14->{
                Symbol temp = symbolStack.peek();
                symbolStack.pop();
                symbolStack.push(new Symbol(production.head(),temp.vary));
                break;
            }
            case 11->{  //A -> A * B;
                Symbol rhs = symbolStack.peek();
                symbolStack.pop();
                symbolStack.pop();
                Symbol lhs = symbolStack.peek();
                symbolStack.pop();
                IRVariable temp = IRVariable.temp();
                Instruction instruction = Instruction.createMul(temp,lhs.vary,rhs.vary);
                IR_list.add(instruction);
                symbolStack.push(new Symbol(production.head(),temp));
                break;
            }
            case 13->{  //B -> ( E );
                symbolStack.pop();
                Symbol symbol = symbolStack.peek();
                symbolStack.pop();
                symbolStack.pop();
                symbolStack.push(new Symbol(production.head(),symbol.vary));
                break;
            }
            case 15->{   //B -> IntConst;
                Symbol temp = symbolStack.peek();
                symbolStack.pop();
                Symbol head = new Symbol(production.head(),temp.vary);
                symbolStack.push(head);
                break;
            }
            default -> {
                break;
            }
        }
    }


    @Override
    public void whenAccept(Status currentStatus) {
        // TODO
        // throw new NotImplementedException();
    }

    @Override
    public void setSymbolTable(SymbolTable table) {
        // TODO
        // throw new NotImplementedException();
    }

    public List<Instruction> getIR() {
        // TODO
        return this.IR_list;
    }

    public void dumpIR(String path) {
        FileUtils.writeLines(path, getIR().stream().map(Instruction::toString).toList());
    }
}

